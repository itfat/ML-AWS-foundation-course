from setuptools import setup

setup(name='statistical_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['statistical_distributions'],
      zip_safe=False)
